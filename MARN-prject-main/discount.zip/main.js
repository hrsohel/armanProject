var navlist = document.getElementById("navlist");

function showMenu(){
    navlist.style.right = "0";
}
function hideMenu(){
    navlist.style.right = "-200px";
}